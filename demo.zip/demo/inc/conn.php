<?php  

$conn = mysqli_connect( 'localhost', 'root', '', 'demo' );
if ( !$conn ) {
	# code...
	die( 'Unable to connect' );
}else{
	echo "Connected";
}

?>