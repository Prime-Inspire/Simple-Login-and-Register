<?php  

session_start();

if ( !$_SESSION['u_name'] ) {
	# code...
	header('Location: login.php');
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Dash</title>
</head>
<body>

Welcome <?php echo $_SESSION['u_name']; ?>

</body>
</html>