<?php include 'inc/conn.php'; ?>
<?php  

session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Demo</title>
</head>
<body>

<form method="POST">
	<table>
		<tr>
			<td>Username:</td>
			<td><input type="text" name="u_name" required></td>
		</tr>
		<tr>
			<td>Password:</td>
			<td><input type="password" name="u_pass" required></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="u_reg"></td>
		</tr>
	</table>
</form>

<?php  

if ( isset($_POST['u_reg']) ) {
	# code...
	$u_name = $_POST['u_name'];
	$u_pass = md5($_POST['u_pass']);

	$sql = "SELECT * FROM users WHERE u_name='$u_name'";
	$result = mysqli_query($conn, $sql);

	if ($result) {
		# code...
		while ( $row = mysqli_fetch_assoc($result) ) {
			# code...
			if ( $u_name == $row['u_name'] && $u_pass == $row['u_pass'] ) {
				# code...
				$_SESSION['u_name'] = $u_name;
				header('Location: dash.php');
			}else{
				echo "Error";
			}
		}
	}
}

?>

</body>
</html>