<?php include 'inc/conn.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Demo</title>
</head>
<body>

<form method="POST">
	<table>
		<tr>
			<td>Email:</td>
			<td><input type="email" name="u_email" required></td>
		</tr>
		<tr>
			<td>Username:</td>
			<td><input type="text" name="u_name" required></td>
		</tr>
		<tr>
			<td>Password:</td>
			<td><input type="password" name="u_pass" required></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="u_reg"></td>
		</tr>
	</table>
</form>

<?php  

if ( isset($_POST['u_reg']) ) {
	# code...
	$u_email = $_POST['u_email'];
	$u_name = $_POST['u_name'];
	$u_pass = md5($_POST['u_pass']);

	$sql = "INSERT INTO users (u_email, u_name, u_pass) VALUES ('$u_email', '$u_name', '$u_pass')";
	if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Registered Successfully!');</script>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

?>

</body>
</html>